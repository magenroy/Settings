# general settings
#c.editor.command = ["urxvt", "-title", "scratchpad", "-geometry", "86x24+40+60", "-e", "nvim", "-f", "{}"]
#c.tabs.background = True

c.concent.headers.user_agent = 'Mozilla/5.0 (Windows NT 10.0; rv:68.0) Gecko/20100101 Firefox/68.0'

c.qt.args = ["blink-settings=darkMode=4"]

configdir = "~/.config/qutebrowser"
CSSsheets = ["dark"]
CSSsheets = " ".join(map(lambda x: configdir + "/css/" + x + ".css", CSSsheets))

config.bind(",n", "config-cycle content.user_stylesheets " + CSSsheets + " \"\"", mode='normal')

#config.colors.webpage.bg = "black"

# searches
c.url.searchengines['DEFAULT'] = 'https://duckduckgo.com/?q={}'
c.url.searchengines['d'] = 'https://duckduckgo.com/?q={}'
c.url.searchengines['g'] = 'http://www.google.com/search?hl=en&source=hp&ie=ISO-8859-l&q={}'
#c.url.searchengines['y'] = 'https://www.youtube.com/results?search_query={}'
c.url.searchengines['wp'] = 'https://secure.wikimedia.org/wikipedia/en/w/index.php?title=Special%%3ASearch&search={}'
c.url.searchengines['wt'] = 'https://secure.wikimedia.org/wiktionary/en/w/index.php?title=Special%%3ASearch&search={}'

c.downloads.position = 'bottom'
c.downloads.remove_finished = 10000 # wait 10 seconds to remove downloads

c.auto_save.session = True

c.session.lazy_restore = True

c.completion.show = 'auto'

c.confirm_quit = ["multiple-tabs", "downloads"]

c.content.autoplay = False

c.content.default_encoding = "uft8"

#c.content.pdfjs = True

c.tabs.background = True

c.tabs.last_close = "close"

# keybinds

config.unbind('<Ctrl-t>', mode='normal') #new tab
config.unbind('<Ctrl-n>', mode='normal') #new window
config.unbind('ga', mode='normal') #new tab
config.unbind('gt', mode='normal') #switch tabs by name (:buffer)
config.unbind('gC', mode='normal') #clone tab
config.unbind('gf', mode='normal') #view page source
config.unbind('T', mode='normal') #tab focus
config.unbind('gu', mode='normal') #navigate up in url
config.unbind('gU', mode='normal') #navigate up in url in new tab
config.unbind('sf', mode='normal') #save config
config.unbind('ss', mode='normal') #set config
config.unbind('sl', mode='normal') #set temporary setting
config.unbind('sk', mode='normal') #bind key
config.unbind('Ss', mode='normal') #show settings
config.unbind('wi', mode='normal') #open web inspector
config.unbind('gd', mode='normal') #download page
config.unbind('ad', mode='normal') #cancel download
config.unbind('co', mode='normal') #close other tabs
config.unbind('cd', mode='normal') #clear downloads
config.unbind('J', mode='normal') #tab-next
config.unbind('K', mode='normal') #tab-prev
config.unbind('M', mode='normal') #bookmark-add

config.unbind('r', mode='normal') #reload
config.bind('rr', 'reload', mode='normal') #reload

config.unbind('d', mode='normal') # close tab
config.bind('dd', 'tab-close', mode='normal') # close tab

config.unbind('m', mode='normal') #quickmark-save
config.bind('m', 'enter-mode set_mark', mode='normal')
config.unbind('`', mode='normal') #enter-mode set_mark
config.bind('`', 'enter-mode jump_mark', mode='normal')


config.bind('gt', 'tab-next', mode='normal')
config.bind('gT', 'tab-prev', mode='normal')

config.bind('<Ctrl-o>', 'back', mode='normal') # corresponds to older jump
config.bind('<Ctrl-i>', 'forward', mode='normal') # corresponds to newer jump

#
#config.unbind('gb', mode='normal')
#config.unbind('b', mode='normal')
#config.unbind('<Ctrl-B>', mode='normal')
#config.bind('<Ctrl-r>', 'restart', mode='normal')
##config.bind('b', 'back', mode='normal')
##config.bind('t', 'set-cmd-text -s :open -t', mode='normal')
#config.bind('<Ctrl-[>', 'leave-mode', mode='passthrough')
##config.bind('gi', 'enter-mode insert ;; jseval --quiet var inputs = document.getElementsByTagName("input"); for(var i = 0; i < inputs.length; i++) { var hidden = false; for(var j = 0; j < inputs[i].attributes.length; j++) { hidden = hidden || inputs[i].attributes[j].value.includes("hidden"); }; if(!hidden) { inputs[i].focus(); break; } }')
##config.bind('<Ctrl-p>', 'jseval document.location=\'https://pinboard.in/add?next=same&url=\'+encodeURIComponent(location.href)+\'&title=\'+encodeURIComponent(document.title)', mode="normal")
