# general settings
#c.editor.command = ["urxvt", "-title", "scratchpad", "-geometry", "86x24+40+60", "-e", "nvim", "-f", "{}"]
c.editor.command = ['urxvt', '-e', 'vim', '-f', '{file}', '-c', 'normal {line}G{column0}l']
#c.tabs.background = True

c.qt.args = ["blink-settings=darkMode=4"]

configdir = "~/.config/qutebrowser"
CSSsheets = ["dark"]
CSSsheets = " ".join(map(lambda x: configdir + "/css/" + x + ".css", CSSsheets))

config.bind(",n", "config-cycle content.user_stylesheets " + CSSsheets + " \"\"", mode='normal')

#config.colors.webpage.bg = "black"
#c.colors.webpage.prefers_color_scheme_dark = True

# searches
c.url.searchengines['DEFAULT'] = 'https://duckduckgo.com/?q={}'
c.url.searchengines['ddg'] = 'https://duckduckgo.com/?q={}'
c.url.searchengines['google'] = 'http://www.google.com/search?hl=en&source=hp&ie=ISO-8859-l&q={}'
#c.url.searchengines['y'] = 'https://www.youtube.com/results?search_query={}'
#c.url.searchengines['wp'] = 'https://secure.wikimedia.org/wikipedia/en/w/index.php?title=Special%%3ASearch&search={}'
#c.url.searchengines['wt'] = 'https://secure.wikimedia.org/wiktionary/en/w/index.php?title=Special%%3ASearch&search={}'
for lang in ["en", "fr", "ru", "pt", "es", "it"]:
    c.url.searchengines['google-' + lang] = \
    'http://www.google.com/search?hl={}&source=hp&ie=ISO-8859-l&q={{}}'.format(lang)
    c.url.searchengines['wp-' + lang] = 'https://{}.wikipedia.org/wiki/{{}}'.format(lang)
    c.url.searchengines['wt-' + lang] = 'https://{}.wiktionary.org/wiki/{{}}'.format(lang)
c.url.searchengines['rae'] = 'https://dle.rae.es/{}'
#c.url.searchengines['es-thes'] = 'https://www.sinonimosonline.com/{}/'
c.url.searchengines['iedra'] = 'https://iedra.es/palabras/?q={}'
c.url.searchengines['es-thes'] = 'https://www.wordreference.com/sinonimos/{}'
c.url.searchengines['pt-thes'] = 'https://www.sinonimos.com.br/{}/'
c.url.searchengines['treccani-thes'] = 'https://www.treccani.it/vocabolario/{}_(Sinonimi-e-Contrari)'
c.url.searchengines['it-thes'] = 'https://sinonimi.it/{}/'
c.url.searchengines['it-dic'] = 'https://www.treccani.it/vocabolario/{}/'
c.url.searchengines['pt-dic'] = 'https://www.dicio.com.br/{}/'
c.url.searchengines['wr-es'] = 'https://www.wordreference.com/es/translation.asp?tranword={}'
c.url.searchengines['wr-pt'] = 'https://www.wordreference.com/ptes/{}'
c.url.searchengines['wr-ru'] = 'https://www.wordreference.com/enru/{}'
c.url.searchengines['wr-it'] = 'https://www.wordreference.com/iten/{}'

c.downloads.position = 'bottom'
c.downloads.remove_finished = 15000 # wait 10 seconds to remove downloads

c.input.insert_mode.auto_enter = True

c.auto_save.session = True

c.session.lazy_restore = True

c.completion.show = 'auto'

c.confirm_quit = ["multiple-tabs", "downloads"]

c.content.autoplay = False

c.content.default_encoding = "uft8"

#c.content.pdfjs = True

c.tabs.background = True

c.tabs.last_close = "close"

# keybinds

config.unbind('<Ctrl-t>', mode='normal') #new tab
config.unbind('<Ctrl-n>', mode='normal') #new window
config.unbind('ga', mode='normal') #new tab
config.unbind('gt', mode='normal') #switch tabs by name (:buffer)
config.unbind('gC', mode='normal') #clone tab
config.unbind('gf', mode='normal') #view page source
config.unbind('T', mode='normal') #tab focus
config.unbind('gu', mode='normal') #navigate up in url
config.unbind('gU', mode='normal') #navigate up in url in new tab
config.unbind('sf', mode='normal') #save config
config.unbind('ss', mode='normal') #set config
config.unbind('sl', mode='normal') #set temporary setting
config.unbind('sk', mode='normal') #bind key
config.unbind('Ss', mode='normal') #show settings
config.unbind('wi', mode='normal') #open web inspector
config.unbind('gd', mode='normal') #download page
config.unbind('ad', mode='normal') #cancel download
config.unbind('co', mode='normal') #close other tabs
config.unbind('cd', mode='normal') #clear downloads
config.unbind('J', mode='normal') #tab-next
config.unbind('K', mode='normal') #tab-prev
config.unbind('M', mode='normal') #bookmark-add

config.unbind('r', mode='normal') #reload
config.bind('rr', 'reload', mode='normal') #reload

config.unbind('d', mode='normal') # close tab
config.bind('dd', 'tab-close', mode='normal') # close tab

config.unbind('m', mode='normal') #quickmark-save
config.bind('m', 'enter-mode set_mark', mode='normal')
config.unbind('`', mode='normal') #enter-mode set_mark
config.bind('`', 'enter-mode jump_mark', mode='normal')


config.bind('gt', 'tab-next', mode='normal')
config.bind('gT', 'tab-prev', mode='normal')

config.bind('<Ctrl-o>', 'back', mode='normal') # corresponds to older jump
config.bind('<Ctrl-i>', 'forward', mode='normal') # corresponds to newer jump

# video viewing things
config.bind(',vv', 'hint links spawn --detach mpv --force-window=immediate {hint-url}')
config.bind(',v3', 'hint links spawn --detach mpv --profile=360p --force-window=immediate {hint-url}')
config.bind(',v4', 'hint links spawn --detach mpv --profile=480p --force-window=immediate {hint-url}')
config.bind(',VV', 'spawn --detach mpv --force-window=immediate {url}')
config.bind(',V3', 'spawn --detach mpv --profile=360p --force-window=immediate {url}')
config.bind(',V4', 'spawn --detach mpv --profile=480p --force-window=immediate {url}')


#
#config.unbind('gb', mode='normal')
#config.unbind('b', mode='normal')
#config.unbind('<Ctrl-B>', mode='normal')
#config.bind('<Ctrl-r>', 'restart', mode='normal')
##config.bind('b', 'back', mode='normal')
##config.bind('t', 'set-cmd-text -s :open -t', mode='normal')
#config.bind('<Ctrl-[>', 'leave-mode', mode='passthrough')
##config.bind('gi', 'enter-mode insert ;; jseval --quiet var inputs = document.getElementsByTagName("input"); for(var i = 0; i < inputs.length; i++) { var hidden = false; for(var j = 0; j < inputs[i].attributes.length; j++) { hidden = hidden || inputs[i].attributes[j].value.includes("hidden"); }; if(!hidden) { inputs[i].focus(); break; } }')
##config.bind('<Ctrl-p>', 'jseval document.location=\'https://pinboard.in/add?next=same&url=\'+encodeURIComponent(location.href)+\'&title=\'+encodeURIComponent(document.title)', mode="normal")



#from https://github.com/nebulaeandstars/dotfiles/blob/master/home/qutebrowser/.config/qutebrowser/config.py
###########################################################################
## COLORS # COLORS # COLORS # COLORS # COLORS # COLORS # COLORS # COLORS ##
###########################################################################

# color variables
cream = "#ffffd8"
mauve = "#ffd8ff"
sky = "#d8ffff"

color0 = "#2d2d2d"
color1 = "#b63740"
color2 = "#34b374"
color3 = "#ad7c4d"
color4 = "#5299c1"
color5 = "#af79d8"
color6 = "#5bc2ad"
color7 = "#999990"
color8 = "#616161"
color9 = "#e9616b"
color10 = "#60eca6"
color11 = "#ebe85f"
color12 = "#8ccbf3"
color13 = "#f09eee"
color14 = "#b4ecee"
color15 = "#ffffff"

black = color0
brightblack = color8
red = color1
brightred = color9
green = color2
brightgreen = color10
yellow = color3
brightyellow = color11
blue = color4
brightblue = color12
magenta = color5
brightmagenta = color13
cyan = color6
brightcyan = color14
white = color7
brightwhite = color15


## COMPLETION WIDGET # COMPLETION WIDGET # COMPLETION WIDGET #
#
### completion widget category headers
#c.colors.completion.category.bg = black
#c.colors.completion.category.border.bottom = brightblue
#c.colors.completion.category.border.top = black
#c.colors.completion.category.fg = brightwhite
#
## completion widget rows
#c.colors.completion.even.bg = black
#c.colors.completion.odd.bg = black
#
## completion widget columns
#c.colors.completion.fg = [brightwhite, brightwhite, brightwhite]
#
## selected completion item
#c.colors.completion.item.selected.bg = black
#c.colors.completion.item.selected.border.bottom = brightgreen
#c.colors.completion.item.selected.border.top = black
#c.colors.completion.item.selected.fg = brightwhite
#
## completion matches
#c.colors.completion.item.selected.match.fg = brightgreen
#c.colors.completion.match.fg = brightblue
#
## widget scrollbar
#c.colors.completion.scrollbar.bg = black
#c.colors.completion.scrollbar.fg = brightwhite
#

# CONTEXT MENU # CONTEXT MENU # CONTEXT MENU # CONTEXT MENU # CONTEXT MENU #

# context menu
c.colors.contextmenu.menu.bg = black
c.colors.contextmenu.menu.fg = brightwhite

# context menu selection
c.colors.contextmenu.selected.bg = brightblack
c.colors.contextmenu.selected.fg = brightwhite

## context menu disabled items
#c.colors.contextmenu.disabled.bg = black
#c.colors.contextmenu.disabled.fg = brightblack


## DOWNLOADS # DOWNLOADS # DOWNLOADS # DOWNLOADS # DOWNLOADS # DOWNLOADS #
#
## download bar
#c.colors.downloads.bar.bg = black
#c.colors.downloads.start.bg = blue
#c.colors.downloads.start.fg = black
#c.colors.downloads.stop.bg = brightgreen
#c.colors.downloads.stop.fg = black
#c.colors.downloads.system.bg = 'rgb'
#c.colors.downloads.system.fg = 'rgb'
#
## download bar with errors
#c.colors.downloads.error.bg = red
#c.colors.downloads.error.fg = brightwhite
#
#
## HINTS # HINTS # HINTS # HINTS # HINTS # HINTS # HINTS # HINTS # HINTS #
#
## hints
#c.colors.hints.bg = cyan
#c.colors.hints.fg = black
#c.hints.border = "2px solid " + blue
#c.colors.hints.match.fg = brightblack
#
### keyhint widget
#c.colors.keyhint.bg = 'rgba(10, 10, 10, 80%)'
#c.colors.keyhint.fg = brightwhite
#
## keys to complete chain in keyhint widget
#c.colors.keyhint.suffix.fg = brightblue
#
#
## MESSAGES # MESSAGES # MESSAGES # MESSAGES # MESSAGES # MESSAGES #
#
## error messages
#c.colors.messages.error.bg = red
#c.colors.messages.error.border = red
#c.colors.messages.error.fg = brightwhite
#
## info messages
#c.colors.messages.info.bg = black
#c.colors.messages.info.border = black
#c.colors.messages.info.fg = brightwhite
#
#c.colors.messages.warning.bg = brightyellow
#c.colors.messages.warning.border = brightyellow
#c.colors.messages.warning.fg = black
#
#
## PROMPTS # PROMPTS # PROMPTS # PROMPTS # PROMPTS # PROMPTS # PROMPTS #
#
## prompts
#c.colors.prompts.bg = black
#c.colors.prompts.border = "1px solid " + brightblack
#c.colors.prompts.fg = brightwhite
#
### selected item in filename prompts
#c.colors.prompts.selected.bg = brightblack
#
#
## STATUSBAR # STATUSBAR # STATUSBAR # STATUSBAR # STATUSBAR # STATUSBAR #
#
## statusbar in normal mode
#c.colors.statusbar.normal.bg = black
#c.colors.statusbar.normal.fg = brightwhite
#
## statusbar in caret mode
#c.colors.statusbar.caret.bg = blue
#c.colors.statusbar.caret.fg = brightwhite
#
## statusbar in caret mode with selection
#c.colors.statusbar.caret.selection.bg = blue
#c.colors.statusbar.caret.selection.fg = brightwhite
#
## statusbar in command mode
#c.colors.statusbar.command.bg = black
#c.colors.statusbar.command.fg = brightwhite
#
## statusbar in command mode with private browsing
#c.colors.statusbar.command.private.bg = magenta
#c.colors.statusbar.command.private.fg = brightwhite
#
## statusbar in insert mode
#c.colors.statusbar.insert.bg = green
#c.colors.statusbar.insert.fg = brightwhite
#
## statusbar in passthrough mode
#c.colors.statusbar.passthrough.bg = cyan
#c.colors.statusbar.passthrough.fg = brightwhite
#
## statusbar in private browsing mode
#c.colors.statusbar.private.bg = magenta
#c.colors.statusbar.private.fg = brightwhite
#
## statusbar url
#c.colors.statusbar.url.fg = brightwhite # while loading
#c.colors.statusbar.url.success.http.fg = brightyellow # loaded http
#c.colors.statusbar.url.success.https.fg = brightgreen # loaded https
#
#c.colors.statusbar.url.hover.fg = brightcyan # hovering over links
#c.colors.statusbar.url.error.fg = brightred # with error
#c.colors.statusbar.url.warn.fg = yellow # with warning
#
## progress bar
#c.colors.statusbar.progress.bg = brightwhite
#
#
## TABS # TABS # TABS # TABS # TABS # TABS # TABS # TABS # TABS # TABS #
#
## tab bar
#c.colors.tabs.bar.bg = brightblack
#
## tab indicator
#c.colors.tabs.indicator.start = blue
#c.colors.tabs.indicator.stop = brightgreen
#c.colors.tabs.indicator.system = 'rgb'
#
#c.colors.tabs.indicator.error = red
#
## unselected tabs
#c.colors.tabs.even.bg = "#3e3e3e"
#c.colors.tabs.even.fg = brightwhite
#c.colors.tabs.odd.bg = "#3e3e3e"
#c.colors.tabs.odd.fg = brightwhite
#
## pinned unselected tabs
#c.colors.tabs.pinned.even.bg = brightblack
#c.colors.tabs.pinned.even.fg = brightcyan
#c.colors.tabs.pinned.odd.bg = brightblack
#c.colors.tabs.pinned.odd.fg = brightcyan
#
## selected tabs
#c.colors.tabs.selected.even.bg = black
#c.colors.tabs.selected.even.fg = brightwhite
#c.colors.tabs.selected.odd.bg = black
#c.colors.tabs.selected.odd.fg = brightwhite
#
## pinned selected tabs
#c.colors.tabs.pinned.selected.even.bg = black
#c.colors.tabs.pinned.selected.even.fg = brightcyan
#c.colors.tabs.pinned.selected.odd.bg = black
#c.colors.tabs.pinned.selected.odd.fg = brightwhite
