#!/bin/sh

SINKS:
	State (H)
	Name (NH)
	Description (H)
	Mute (H)
	Volume (H with adjustments)

SINK-INPUTS:
	Mute (H)
	Volume (H with adjustments)
	(Properties)
		application.name (H?)
